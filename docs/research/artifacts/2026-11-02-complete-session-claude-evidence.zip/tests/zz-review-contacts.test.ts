import { expect, test } from 'vitest'
import { createNativeContactDraft, measureNativeContacts } from '../../src/ui/motion-lab/native-contacts.ts'
import { livePlaybackDelta } from '../../src/studio/experience/presentation.ts'
import { integrateMovement } from '../../src/studio/experience/movement.ts'

test('REVIEW looping stance that crosses the loop seam: span uses absolute playback start time without wrap', () => {
  const h = `sha256:${'a'.repeat(64)}`
  const draft = createNativeContactDraft({ id: 'x', hashes: Array(8).fill(h), cell: { w: 128, h: 128 }, direction: 'east', durations: Array(8).fill(100), loop: true })
  draft.speed = { x: 22.5, y: 0 }
  // A world-planted foot: frame 7 at x=60, next cycle frame 0 is 2.25 px further back (rounded to 58).
  draft.marks = [{ frame: 6, track: 'A', landmark: 'heel', stance: 'seam', x: 62, y: 90 }, { frame: 7, track: 'A', landmark: 'heel', stance: 'seam', x: 60, y: 90 }, { frame: 0, track: 'A', landmark: 'heel', stance: 'seam', x: 58, y: 90 }]
  const span = measureNativeContacts(draft).stances[0].boundarySpanPx!
  const control = { ...draft, marks: draft.marks.map(m => m.frame === 0 ? m : m) }
  console.log('seam span px', span.toFixed(2), '(non-seam equivalent would be about 0.5)')
  expect(span).toBeLessThan(2)
})

test('REVIEW cadence: leg time per unit of travel is constant across analog strengths (pointer path)', () => {
  const anim = { kind: 'animation', moving: true, requestedClip: 'walk', clip: 'walk' } as never
  const ratios = [0.174, 0.5, 0.99, 1, 1.4].map(m => {
    const v = { x: m, y: 0 }, legs = livePlaybackDelta(anim, v, 16), travel = integrateMovement({ x: 0, y: 0 }, { x: 0, y: 0 }, v, 0.016, 95).position.x
    return legs / travel
  })
  console.log('legs/travel ratios', ratios.map(r => r.toFixed(4)).join(' '))
  expect(new Set(ratios.slice(0, 4).map(r => r.toFixed(6))).size).toBe(1)
  // magnitude > 1 cannot be produced by pointerVector/keyboardVector; with it travel is unclamped while legs are clamped
  expect(livePlaybackDelta(anim, { x: 0, y: 0 }, 16)).toBe(0)
  expect(livePlaybackDelta(anim, { x: NaN, y: 0 }, 16)).toBe(0)
  expect(livePlaybackDelta(anim, { x: 0.5, y: 0 }, Infinity)).toBe(0)
})
