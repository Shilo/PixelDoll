// TEMPORARY reviewer audit (isolated copy only): run Studio's open-time B15 split on retained artifacts.
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { expect, test } from 'vitest';
import { decodePngBytes } from '../../src/lib/image/pngraw.ts';
import { splitBase } from '../../src/lib/dress/regions.ts';
import type { Img } from '../../src/lib/image/png.ts';
import type { Project } from '../../src/lib/store/manifest.ts';
import type { Sha256 } from '../../src/lib/rig/rig.ts';

const ART = process.env.AUDIT_ARTIFACTS!;
async function loadZipDir(dir: string): Promise<Project> {
  const p = JSON.parse(readFileSync(join(dir, 'project.json'), 'utf8')), images = new Map<Sha256, Img>();
  for (const f of readdirSync(join(dir, 'cells'))) images.set(`sha256:${f.slice(0, -4)}` as Sha256, await decodePngBytes(new Uint8Array(readFileSync(join(dir, 'cells', f)))));
  return { manifest: p.manifest, images };
}
function audit(before: Img, after: Img) {
  let blueLsb = 0, other = 0; const where: number[] = [];
  for (let i = 0; i < before.data.length; i++) {
    const d = before.data[i] ^ after.data[i];
    if (!d) continue;
    if (i % 4 === 2 && d === 1) { blueLsb++; if (where.length < 3) where.push(i >> 2); } else other++;
  }
  return { blueLsb, other, where };
}
for (const name of ['studio', 'starter'] as const) test(`B15 split on ${name}`, async () => {
  const project = await loadZipDir(join(ART, name)), m = project.manifest, base = m.items.find(i => i.id === m.rig.baseItem)!;
  const before = structuredClone(base.layers[0].cells) as Record<string, Record<string, Sha256[]>>;
  const originals = new Map(project.images);
  const split = await splitBase(project);
  const after = base.layers[0].cells as Record<string, Record<string, Sha256[]>>;
  const rows: string[] = []; let totalOther = 0;
  for (const [anim, dirs] of Object.entries(before)) for (const [dir, hashes] of Object.entries(dirs)) hashes.forEach((h, i) => {
    const a = audit(originals.get(h)!, project.images.get(after[anim][dir][i])!); totalOther += a.other;
    if (a.blueLsb || a.other) rows.push(`${anim}/${dir}/${i}: blueLSB=${a.blueLsb} other=${a.other} first=${a.where.map(p => `(${p % originals.get(h)!.w},${(p / originals.get(h)!.w) | 0})`).join(' ')}`);
  });
  console.log(`${name}: changed cells ${split.changed}, dirty ${split.dirty}\n` + rows.join('\n'));
  expect(totalOther).toBe(0);
});
