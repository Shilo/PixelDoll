import { beforeEach, afterEach, expect, test, vi } from 'vitest';
import { makeImg, type Img } from '../../src/lib/image/png.ts';
import { decodePngBytes, encodePngBytes } from '../../src/lib/image/pngraw.ts';
import { sha256 } from '../../src/lib/image/hash.ts';
import { cellHash, DIRECTIONS, type DirectionName, type Rig, type Sha256 } from '../../src/lib/rig/rig.ts';
import { LABELS } from '../../src/lib/rig/poses.ts';
import { CURRENT_FORMAT, type Project } from '../../src/lib/store/manifest.ts';
import type { StoredProject } from '../../src/lib/store/project.ts';
import type { JobRec } from '../../src/lib/pixellab/queue.ts';
import type { Req } from '../../src/lib/pixellab/routes.ts';
import type { StarterPlan, StarterPresetId } from '../../src/lib/rig/starter-presets.ts';

const mocks = vi.hoisted(() => ({ loadProject: vi.fn(), api: vi.fn(), enqueue: vi.fn(), get: vi.fn(), getBlob: vi.fn(), putCharacter: vi.fn() }));
vi.mock('../../src/lib/store/project.ts', () => ({ loadProject: mocks.loadProject }));
vi.mock('../../src/lib/store/db.ts', () => ({ get: mocks.get, getBlob: mocks.getBlob, putCharacter: mocks.putCharacter }));
vi.mock('../../src/lib/pixellab/client.ts', () => ({ api: mocks.api }));
vi.mock('../../src/ui/motion-lab/run.ts', () => ({ LAB_TAG: 'unit-starter', labQueue: { key: 'synthetic-unit-fixture', enqueue: mocks.enqueue } }));
import { describeStarterPilot, loadStarterSource, prepareStarter, readStarter, starterFrames, starterHeld, starterJobs, submitStarter, STARTER_CAP, STARTER_KEY, type StarterSession } from '../../src/ui/motion-lab/starter-pack.ts';

const PILOT: DirectionName[] = ['south', 'east'];
const MORE = DIRECTIONS.filter(d => !PILOT.includes(d));
let storage: Map<string, string>, records: Map<string, JobRec>, blobs: Map<string, Blob>;
let source: { rec: StoredProject; project: Project }, standing: Map<DirectionName, Uint8Array>;
let originalAvailable: boolean, snapshotRecords: Map<string, StoredProject>, snapshotImages: Map<string, Map<Sha256, Img>>;

function job(id: string, overrides: Partial<JobRec> = {}): JobRec {
  return { id, label: 'Synthetic starter transport', method: 'POST', endpoint: '/characters/animations', params: {}, inputs: [], requestHash: id,
    state: 'queued', attempts: 0, nextAt: 0, createdAt: 0, jobs: [], gens: 0, usd: 0, ...overrides };
}
function persist(session: StarterSession) { storage.set(STARTER_KEY, JSON.stringify(session)); }
function bindings(session: StarterSession) { return Object.fromEntries(Object.entries(session.plans).map(([id, p]) => [id, p.binding])); }
const serverCharacter = () => ({ id: 'unit-character', template_id: 'mannequin', view: 'low top-down',
  rotation_urls: Object.fromEntries(DIRECTIONS.map(d => [d, `https://backblaze.pixellab.ai/unit/${d}.png`])) });

beforeEach(async () => {
  vi.clearAllMocks();
  storage = new Map(); records = new Map(); blobs = new Map(); standing = new Map(); originalAvailable = true; snapshotRecords = new Map(); snapshotImages = new Map();
  vi.stubGlobal('localStorage', { getItem: (key: string) => storage.get(key) ?? null, setItem: (key: string, value: string) => { storage.set(key, value); } });
  vi.stubGlobal('navigator', { locks: { request: async (_name: string, callback: () => unknown) => callback() } });
  const images = new Map<Sha256, Img>(), rest: NonNullable<Rig['rest']> = {}, cells: Partial<Record<DirectionName, Sha256[]>> = {};
  for (const [i, direction] of DIRECTIONS.entries()) {
    const image = makeImg(32, 32); image.data.set([100 + i, 50, 30, 255], (10 * 32 + 15) * 4); image.data.set([50, 30, 10, 255], (30 * 32 + 16) * 4);
    const hash = await cellHash(image); images.set(hash, image); cells[direction] = [hash]; standing.set(direction, await encodePngBytes(image));
    rest[direction] = { image: hash, keypoints: LABELS.map(label => ({ label, x: .5, y: .5 })) };
  }
  const rig: Rig = { template: 'mannequin', view: 'low top-down', cell: { w: 32, h: 32 }, pivot: { x: 16, y: 31 },
    directions: DIRECTIONS.map(id => ({ id })), baseItem: 'body', baseHash: `sha256:${'a'.repeat(64)}`, rest,
    animations: [{ id: 'default', cells: 1, loop: true, frames: [{ cell: 0, ms: 150 }] }] };
  const project: Project = { images, manifest: { format: CURRENT_FORMAT, name: 'Synthetic native eight', app: 'Unit fixture only', rig, materials: [],
    slots: [{ id: 'body', z: 10, class: 'base', required: true }], presets: [],
    items: [{ id: 'body', name: 'Fixture body', slot: 'body', status: 'accepted', mirror: 'generate', materials: [], prompt: 'Synthetic test pixels',
      baseHash: rig.baseHash, provenance: [], layers: [{ id: 'main', z: 10, role: 'fg', cells: { default: cells } }] }] } };
  source = { project, rec: { id: 'rig-starter-unit', savedAt: '', manifest: project.manifest, character: { id: 'unit-character', looks: 'Synthetic native source' }, origin: 'studio' } };
  mocks.loadProject.mockReset().mockImplementation(async (id: string) => {
    if (id === source.rec.id && originalAvailable) return source;
    const snapshot = snapshotRecords.get(id), images = snapshotImages.get(id);
    if (!snapshot || !images) throw new Error('Synthetic source project is unavailable.');
    const rec = structuredClone(snapshot);
    return { rec, project: { manifest: rec.manifest, images: new Map([...images].map(([hash, image]) => [hash, structuredClone(image)])) } };
  });
  mocks.api.mockReset().mockImplementation(async () => serverCharacter());
  mocks.get.mockReset().mockImplementation(async (table: string, id: string) => table === 'projects' ? snapshotRecords.get(id) : records.get(id));
  mocks.getBlob.mockReset().mockImplementation(async (id: string) => blobs.get(id));
  mocks.putCharacter.mockReset().mockImplementation(async (id: string, record: StoredProject, images: Map<string, Blob>) => {
    if (snapshotRecords.has(id)) throw new Error('Synthetic snapshot already exists.');
    const decoded = new Map<Sha256, Img>();
    for (const [hash, blob] of images) decoded.set(`sha256:${hash}`, await decodePngBytes(new Uint8Array(await blob.arrayBuffer())));
    snapshotRecords.set(id, structuredClone(record)); snapshotImages.set(id, decoded);
  });
  mocks.enqueue.mockReset().mockImplementation(async (_request: Req) => { const queued = job('queued-continuation'); records.set(queued.id, queued); return queued; });
  vi.stubGlobal('fetch', vi.fn(async (address: string | URL | Request) => {
    const url = new URL(String(address)), direction = url.pathname.split('/').at(-1)!.replace('.png', '') as DirectionName, bytes = standing.get(direction);
    if (!bytes) throw new Error('Unexpected synthetic asset request.');
    return new Response(new Blob([bytes as Uint8Array<ArrayBuffer>]), { status: 200 });
  }));
});
afterEach(() => { vi.unstubAllGlobals(); });

async function completedPilot(session: StarterSession, preset: StarterPresetId): Promise<StarterPlan> {
  const plan = session.plans[preset]!, localId = `local-${preset}`;
  const jobs: JobRec['jobs'] = [];
  for (const [d, direction] of PILOT.entries()) {
    const results = [];
    for (let i = 0; i < plan.frames; i++) {
      const image = makeImg(48, 48); image.data.set([90 + d, 60 + i, 40, 255], (20 * 48 + 20) * 4);
      const bytes = await encodePngBytes(image), sha = await sha256(bytes); blobs.set(sha, new Blob([bytes as Uint8Array<ArrayBuffer>]));
      results.push({ label: `${direction}/${i}`, sha, w: 48, h: 48 });
    }
    jobs.push({ id: `${preset}-${direction}`, status: 'completed', done: true, results });
  }
  records.set(localId, job(localId, { state: 'done', jobs, gens: 6, response: { animation_group_id: `group-${preset}`, directions: PILOT, background_job_ids: jobs.map(j => j.id), status: 'processing' } }));
  session.calls.push({ id: `hold-${preset}`, plan, directions: [...PILOT], units: 8, recordId: localId }); persist(session); return plan;
}

// ---------------- TEMPORARY REVIEWER COUNTEREXAMPLES (isolated copy only) ----------------

/** Verbatim keep predicate from src/studio/state.svelte.ts cleanUp() with no Studio drafts, fits or flows. */
const studioKeep = (maxAge: number, now: number) => (r: JobRec) => (r.finishedAt ?? r.createdAt) > now - maxAge;
const WEEK = 7 * 86_400_000;

test('AUDIT-1a: the Studio queue sees and prunes finished Motion Lab starter records', async () => {
  const { Queue } = await vi.importActual<typeof import('../../src/lib/pixellab/queue.ts')>('../../src/lib/pixellab/queue.ts');
  const store = new Map<string, JobRec>();
  const now = 30 * 86_400_000;
  store.set('starter-walk', job('starter-walk', { tag: 'motion-lab-2026-10-28', state: 'done', createdAt: now - 8 * 86_400_000, finishedAt: now - 8 * 86_400_000 }));
  const q = new Queue({ all: async () => [...store.values()], put: async (k, r) => { store.set(k, r); }, get: async k => store.get(k), del: async k => store.delete(k),
    locks: null, channel: 'audit-' + Math.random(), now: () => now, online: () => true, api: async () => { throw new Error('no network in audit'); } });
  await q.connect();
  const removedByStartupPrune = await q.clearFinished(studioKeep(WEEK, now)); // drive() -> cleanUp(WEEK, false) at every Studio leader start
  q.disconnect();
  expect(removedByStartupPrune).toBe(1);
  expect(store.has('starter-walk')).toBe(false);
});

test('AUDIT-1b: a pruned starter record strands free review/export, including a missing optional idle record', async () => {
  const session = await prepareStarter(source.rec.id);
  await completedPilot(session, 'walk'); await completedPilot(session, 'slash'); await completedPilot(session, 'idle');
  records.delete('local-idle'); // Studio cleanUp removed the finished rejected-idle record
  await expect(starterJobs(readStarter())).rejects.toThrow('reserved starter job is missing'); // StarterPack.refresh() and loadPack() both call this first
  await expect(loadStarterSource(readStarter())).resolves.toBeTruthy(); // only the source is pinned
});

test('AUDIT-2: another tab can change the prepared source; this tab then pays for a source it is not displaying', async () => {
  const other = structuredClone(source.rec), otherImages = new Map<Sha256, Img>(), otherRest: NonNullable<Rig['rest']> = {}, otherBytes = new Map<DirectionName, Uint8Array>();
  for (const [i, direction] of DIRECTIONS.entries()) {
    const image = makeImg(32, 32); image.data.set([10 + i, 200, 30, 255], (12 * 32 + 15) * 4);
    const hash = await cellHash(image); otherImages.set(hash, image); otherBytes.set(direction, await encodePngBytes(image));
    otherRest[direction] = { image: hash, keypoints: LABELS.map(label => ({ label, x: .5, y: .5 })) };
  }
  other.id = 'rig-other-unit'; other.character = { id: 'other-character', looks: 'Second source' }; other.manifest.rig.rest = otherRest;
  const otherProject = { rec: other, project: { manifest: other.manifest, images: otherImages } };
  const base = mocks.loadProject.getMockImplementation()!;
  mocks.loadProject.mockImplementation(async (id: string) => id === other.id ? otherProject : base(id));
  mocks.api.mockImplementation(async (_key: string, _method: string, path: string) => path.endsWith('other-character')
    ? { ...serverCharacter(), id: 'other-character', rotation_urls: Object.fromEntries(DIRECTIONS.map(d => [d, `https://backblaze.pixellab.ai/other/${d}.png`])) } : serverCharacter());
  vi.stubGlobal('fetch', vi.fn(async (address: string | URL | Request) => {
    const url = new URL(String(address)), d = url.pathname.split('/').at(-1)!.replace('.png', '') as DirectionName;
    const bytes = (url.pathname.includes('/other/') ? otherBytes : standing).get(d)!;
    return new Response(new Blob([bytes as Uint8Array<ArrayBuffer>]), { status: 200 });
  }));
  const tab1 = await prepareStarter(source.rec.id);       // tab 1 shows source A; `prepared` = selected === session.projectId
  await prepareStarter(other.id);                         // tab 2 prepares source B (allowed: no calls yet)
  await submitStarter('walk', PILOT);                     // tab 1 clicks "Generate south + east" with its stale session
  expect(tab1.projectId).toBe(source.rec.id);
  expect(mocks.enqueue.mock.calls[0][0].body.character_id).toBe('other-character');
});

test('AUDIT-3: a provably unsent failed pilot permanently blocks the action and any changed source, with no explicit resolution path', async () => {
  const session = await prepareStarter(source.rec.id);
  session.calls.push({ id: 'never-sent', plan: session.plans.walk!, directions: [...PILOT], units: 8, recordId: 'never-sent' }); persist(session);
  records.set('never-sent', job('never-sent', { state: 'failed', requestStarted: false, error: 'page closed before request preparation finished; nothing was sent.' }));
  await expect(submitStarter('walk', PILOT)).rejects.toThrow('unfinished');
  await expect(starterFrames(readStarter(), 'walk', await starterJobs(readStarter()))).rejects.toThrow('unfinished');
  const replacement = makeImg(32, 32); replacement.data.set([120, 40, 20, 255], 0); const hash = await cellHash(replacement);
  source.project.images.set(hash, replacement); source.rec.manifest.rig.rest!.south!.image = hash;
  await expect(prepareStarter(source.rec.id)).rejects.toThrow('reserved or uncertain');
  expect(starterHeld(readStarter(), await starterJobs(readStarter()))).toBe(8); // the unsent attempt also keeps its hold forever
});
