"""Independent re-render of the rigid axe track (inverse-mapped nearest neighbour, body-only occlusion).
Usage: python -P -E rerender_axe.py <grip dir>"""
import base64, io, json, math, os, sys
import numpy as np
from PIL import Image
G = sys.argv[1]
def load(p): return np.array(Image.open(p).convert('RGBA'), np.uint8)
def b64img(s): return np.array(Image.open(io.BytesIO(base64.b64decode(s))).convert('RGBA'), np.uint8)
auth = json.load(open(os.path.join(G, 'authoring.json'))); man = json.load(open(os.path.join(G, 'manifest.json')))
src = b64img(auth['asset']['png']); grip = auth['asset']['grip']; axis = auth['asset']['axis']
base = math.atan2(axis['y'] - grip['y'], axis['x'] - grip['x'])
def render(gx, gy, target, ang):
    c, s = math.cos(ang), math.sin(ang); H = W = 144
    out = np.zeros((H, W, 4), np.uint8)
    for y in range(H):
        for x in range(W):
            dx, dy = x + .5 - target['x'], y + .5 - target['y']
            sx, sy = math.floor(gx + c * dx + s * dy), math.floor(gy - s * dx + c * dy)
            if 0 <= sx < src.shape[1] and 0 <= sy < src.shape[0]: out[y, x] = src[sy, sx]
    return out
for i, f in enumerate(auth['frames']):
    body = load(os.path.join(G, 'body', f'{i}.png')); layer = load(os.path.join(G, 'layers', f'{i}.png')); occ = b64img(f['occluder'])
    raw = render(grip['x'], grip['y'], f['grip'], f['angle'] * math.pi / 180 - base)
    hide = (body[:, :, 3] > 0) & (occ[:, :, 3] > 0)
    hidden = int(((raw[:, :, 3] > 0) & hide).sum())
    occl = raw.copy(); occl[hide] = 0
    old = render(93, 82, f['grip'], f['angle'] * math.pi / 180 - base)
    old_hidden = int(((old[:, :, 3] > 0) & hide).sum())
    # body colours drawn where the item sits: none expected since item comes only from the source asset
    print(f'frame {i}: rawItemPx={int((raw[:,:,3]>0).sum())} hidden={hidden} manifest={man["frames"][i]["hiddenItemPixels"]} '
          f'layer==rerender:{np.array_equal(occl, layer)} diffPx={int(np.any(occl!=layer,axis=2).sum())} '
          f'oldAnchor(93,82)SameTarget hidden={old_hidden} occluderPx={int((occ[:,:,3]>0).sum())} occluderOnBody={int(hide.sum())}')
