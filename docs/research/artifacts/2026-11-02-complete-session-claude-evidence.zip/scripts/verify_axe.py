"""Independent audit of the east axe native/Studio/engine artifacts.
Usage: python -P -E verify_axe.py <grip dir> <studio dir> <engine dir>"""
import base64, hashlib, io, json, math, os, sys
import numpy as np
from PIL import Image

G, S, E = sys.argv[1:4]
def load(p): return np.array(Image.open(p).convert('RGBA'), np.uint8)
def b64img(s): return np.array(Image.open(io.BytesIO(base64.b64decode(s))).convert('RGBA'), np.uint8)
def h(a): return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()
def colors(a): return {tuple(int(v) for v in px) for px in a.reshape(-1, 4) if px[3] > 0}

auth = json.load(open(os.path.join(G, 'authoring.json'))); man = json.load(open(os.path.join(G, 'manifest.json')))
asset = b64img(auth['asset']['png']); asset_cols = colors(asset)
print('asset', asset.shape, 'opaque', int((asset[:, :, 3] > 0).sum()), 'colors', len(asset_cols), 'partial alpha', int(((asset[:, :, 3] > 0) & (asset[:, :, 3] < 255)).sum()))
g = auth['asset']['grip']; ax = auth['asset']['axis']
print('source grip', g, 'axis', ax, 'move from (93,82):', round(math.hypot(g['x'] - 93, g['y'] - 82), 3))
print('asset pixel at grip floor', asset[int(g['y']), int(g['x'])].tolist(), 'alpha at (72,72) center', asset[72, 72].tolist() if asset.shape[0] > 72 else None)
body_cols_all = set()
bodies, items, prevs = [], [], []
for i in range(8):
    b, it, pv = (load(os.path.join(G, d, f'{i}.png')) for d in ('body', 'layers', 'preview'))
    bodies.append(b); items.append(it); prevs.append(pv); body_cols_all |= colors(b)
    assert hashlib.sha256(open(os.path.join(G, 'body', f'{i}.png'), 'rb').read()).hexdigest() == auth['body']['hashes'][i], f'body {i} png hash'
print('body PNG-file hashes match authoring:', True)
dur = [f['durationMs'] for f in man['frames']]
print('durations', dur, 'loop', man['loop'], 'providerTiming', man['providerTiming'], 'qualified', man['qualified'], [f['qualified'] for f in man['frames']])
for i in range(8):
    b, it, pv = bodies[i], items[i], prevs[i]
    occ = b64img(auth['frames'][i]['occluder'])
    occm = occ[:, :, 3] > 0
    itm = it[:, :, 3] > 0; bm = b[:, :, 3] > 0
    ic = colors(it)
    not_in_asset = ic - asset_cols
    in_body = ic & body_cols_all
    # same-position same-color as body (a copied body pixel)
    same = int((itm & bm & np.all(it == b, axis=2)).sum())
    # composite: item over body except where occluder hides item
    comp = b.copy(); vis = itm & ~occm
    comp[vis] = it[vis]
    partial = int(((it[:, :, 3] > 0) & (it[:, :, 3] < 255)).sum())
    hidden = int((itm & occm).sum())
    occ_outside_body = int((occm & ~bm).sum())
    print(f'frame {i}: itemPx={int(itm.sum())} itemColors={len(ic)} notInAssetPalette={len(not_in_asset)} colorsAlsoInBody={len(in_body)} samePosSameColorAsBody={same} '
          f'partialAlpha={partial} hidden={hidden} (manifest {man["frames"][i]["hiddenItemPixels"]}) occluderOutsideBody={occ_outside_body} preview==composite:{np.array_equal(comp, pv)} '
          f'previewDiffPx={int(np.any(comp != pv, axis=2).sum())} itemOverlapsBody={int((itm & bm).sum())}')
    if not_in_asset: print('   colors not in asset:', sorted(not_in_asset)[:10])
    if in_body: print('   shared colors:', sorted(in_body)[:10])
# rotation consistency: item opaque count vs asset opaque count
print('asset opaque', int((asset[:, :, 3] > 0).sum()), 'item opaque per frame', [int((it[:, :, 3] > 0).sum()) for it in items])

# ---- Studio + engine projects
for name, root in (('studio', S), ('engine', E)):
    p = json.load(open(os.path.join(root, 'project.json'))); m = p.get('manifest', p)
    rig = m['rig']
    print(f'== {name}: cell {rig["cell"]} pivot {rig["pivot"]} dirs {[d["id"] for d in rig["directions"]]}')
    for a in rig['animations']: print('  anim', a['id'], 'cells', a['cells'], 'loop', a.get('loop'), 'ms', [f['ms'] for f in a['frames']], 'playlist', [f['cell'] for f in a['frames']])
    for it in m['items']:
        print('  item', it['id'], it['status'], 'qa', it.get('qa', {}).get('status'), it.get('qa', {}).get('unmeasured'), 'warnings', it.get('designWarnings'), 'provenance', len(it.get('provenance', [])), 'keys', [k for k in it if k not in ('layers', 'coverage', 'prompt', 'qa', 'materials')])
        for L in it['layers']:
            for anim, dirs in L['cells'].items():
                for d, hs in dirs.items():
                    imgs = [load(os.path.join(root, 'cells', x[7:] + '.png')) for x in hs]
                    ref = bodies if it['id'] in ('body', 'base', rig.get('baseItem')) else items
                    eq = [any(np.array_equal(im, r) for r in ref) for im in imgs]
                    idx = [next((j for j, r in enumerate(ref) if np.array_equal(im, r)), None) for im in imgs]
                    print(f'    layer {L["id"]} {anim}/{d}: {len(hs)} cells, equal-to-native index {idx}')
    s = json.dumps(m)
    print('  keypoints' , s.count('keypoints'), 'anchors' in rig, 'qualified' in s, 'fps' in s.lower())
mf = json.load(open(os.path.join(E, 'manifest.json')))
print('engine manifest keys', list(mf.keys())[:30])
print(json.dumps(mf)[:1500])
