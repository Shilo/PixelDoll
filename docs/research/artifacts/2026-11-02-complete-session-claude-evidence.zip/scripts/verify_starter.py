"""Independent offline audit of the eight-direction starter pack artifact.
Usage: python -I verify_starter.py <extracted starter dir> [<extracted review dir>]
Decodes PNGs with Pillow, never with app code."""
import hashlib, json, sys, os
import numpy as np
from PIL import Image

ROOT = sys.argv[1]
REVIEW = sys.argv[2] if len(sys.argv) > 2 else None
DIRS = ['south', 'south-east', 'east', 'north-east', 'north', 'north-west', 'west', 'south-west']
MIRROR = {'east': 'west', 'west': 'east', 'south-east': 'south-west', 'south-west': 'south-east', 'north-east': 'north-west', 'north-west': 'north-east', 'south': 'south', 'north': 'north'}
fail = []

def check(ok, msg):
    if not ok: fail.append(msg)
    return ok

def load(path):
    im = Image.open(path)
    mode = im.mode
    a = np.array(im.convert('RGBA'), dtype=np.uint8)
    return a, mode

def rgba_hash(a):
    return 'sha256:' + hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()

def file_hash(p):
    return 'sha256:' + hashlib.sha256(open(p, 'rb').read()).hexdigest()

def place(a, cell, off):
    h, w = a.shape[:2]
    out = np.zeros((cell, cell, 4), np.uint8)
    ys, xs = np.nonzero(a[:, :, 3])
    if len(xs) and (xs.min() + off[0] < 0 or ys.min() + off[1] < 0 or xs.max() + off[0] >= cell or ys.max() + off[1] >= cell):
        raise ValueError('clips')
    y0, x0 = max(0, off[1]), max(0, off[0])
    sy, sx = y0 - off[1], x0 - off[0]
    hh, ww = min(h - sy, cell - y0), min(w - sx, cell - x0)
    out[y0:y0 + hh, x0:x0 + ww] = a[sy:sy + hh, sx:sx + ww]
    return out

ev = json.load(open(os.path.join(ROOT, 'starter-evidence.json')))
proj = json.load(open(os.path.join(ROOT, 'project.json')))
m = proj['manifest']; rig = m['rig']; L = ev['layout']; CELL = L['cell']['w']
check(L['cell']['w'] == L['cell']['h'] == rig['cell']['w'] == rig['cell']['h'] == 112, 'canvas 112')
layer = m['items'][0]['layers'][0]['cells']
cells_dir = os.path.join(ROOT, 'cells')
cell_files = {f[:-4] for f in os.listdir(cells_dir)}
modes = {}

def cell_img(h):
    p = os.path.join(cells_dir, h[7:] + '.png')
    a, mode = load(p); modes[mode] = modes.get(mode, 0) + 1
    check(rgba_hash(a) == h, f'cell file name != RGBA hash {h}')
    return a

# --- standing raw -> placed -> project default/idle
ro = (L['restOffset']['x'], L['restOffset']['y'])
standing, placed_standing = {}, {}
for r in ev['source']['rest']:
    d = r['direction']; p = os.path.join(ROOT, r['path'])
    a, mode = load(p); modes[mode] = modes.get(mode, 0) + 1
    check(a.shape[:2] == (80, 80), f'standing {d} 80px')
    check(rgba_hash(a) == r['rgbaHash'], f'standing {d} rgba hash'); check(file_hash(p) == r['archivePngHash'], f'standing {d} png hash')
    pl = place(a, CELL, ro); check(rgba_hash(pl) == r['outputHash'], f'standing {d} placed hash')
    check(rig['rest'][d]['image'] == r['outputHash'], f'rig.rest {d}')
    check(layer['default'][d] == [r['outputHash']], f'default {d} cell')
    check(layer['idle'][d] == [r['outputHash']], f'idle {d} == placed default')
    check(np.array_equal(cell_img(r['outputHash']), pl), f'default cell pixels {d}')
    standing[d], placed_standing[d] = a, pl
print('pivot', rig['pivot'], 'source pivot', ev['source']['pivot'], 'restOffset', ro)
check(rig['pivot'] == {'x': ev['source']['pivot']['x'] + ro[0], 'y': ev['source']['pivot']['y'] + ro[1]}, 'pivot = source + restOffset')

anims = {a['id']: a for a in rig['animations']}
print('idle anim', anims['idle']); print('default anim', anims['default'])
check(anims['idle']['cells'] == 1 and [f['ms'] for f in anims['idle']['frames']] == [150] * 4 and all(f['cell'] == 0 for f in anims['idle']['frames']), 'idle 4x150 holds')

# --- raw motion frames
raw = {}
for clip in ev['clips']:
    pid = clip['preset']; raw[pid] = {}
    for fr in clip['frames']:
        p = os.path.join(ROOT, fr['path']); a, mode = load(p); modes[mode] = modes.get(mode, 0) + 1
        check(rgba_hash(a) == fr['rgbaHash'], f'{fr["path"]} rgba'); check(file_hash(p) == fr['archivePngHash'], f'{fr["path"]} png')
        check(a.shape[:2] == (clip['nativeCells'][fr['direction']]['h'], clip['nativeCells'][fr['direction']]['w']), f'{fr["path"]} native size')
        raw[pid].setdefault(fr['direction'], {})[fr['index']] = a
sizes = {pid: {d: sorted({v.shape[0] for v in raw[pid][d].values()}) for d in DIRS} for pid in raw}
print('native sizes', json.dumps(sizes))

# --- raw -> placed -> exported cells, translation only
for pid in ['walk', 'slash']:
    clip = next(c for c in ev['clips'] if c['preset'] == pid); smap = L['sourceFrames'][pid]
    uniq = list(dict.fromkeys(smap))
    anim = anims[pid]
    exp_play = [uniq.index(s) for s in smap]
    check([f['cell'] for f in anim['frames']] == exp_play, f'{pid} playlist'); check(anim['cells'] == len(uniq), f'{pid} cell count')
    print(pid, 'map', smap, 'unique', uniq, 'playlist', [f['cell'] for f in anim['frames']], 'ms', [f['ms'] for f in anim['frames']], 'loop', anim['loop'])
    for d in DIRS:
        off = (L['offsets'][pid][d]['x'], L['offsets'][pid][d]['y'])
        hashes = layer[pid][d]; check(len(hashes) == len(uniq), f'{pid}/{d} cells')
        for ci, si in enumerate(uniq):
            src = raw[pid][d][si]; pl = place(src, CELL, off); got = cell_img(hashes[ci])
            check(np.array_equal(pl, got), f'{pid}/{d}/{ci} placed != exported')
            # translation-only: extracting window returns raw exactly, outside window fully zero
            h, w = src.shape[:2]
            check(np.array_equal(got[off[1]:off[1] + h, off[0]:off[0] + w], src), f'{pid}/{d}/{ci} window')
            mask = np.ones(got.shape[:2], bool); mask[off[1]:off[1] + h, off[0]:off[0] + w] = False
            check(not got[mask].any(), f'{pid}/{d}/{ci} outside window nonzero')
            check(int((src[:, :, 3] > 0).sum()) == int((got[:, :, 3] > 0).sum()), f'{pid}/{d}/{ci} clipped')
        for fr in clip['frames']:
            if fr['direction'] != d: continue
            pc = fr.get('playableCell')
            check((pc is not None) == (fr['index'] in uniq), f'{pid}/{d}/{fr["index"]} playable flag')
            if pc is not None: check(fr['outputHash'] == hashes[pc], f'{pid}/{d}/{fr["index"]} output hash')

# --- every exported cell referenced
refs = {h[7:] for a in layer.values() for v in a.values() for h in v}
print('cell files', len(cell_files), 'referenced', len(refs), 'extra', len(cell_files - refs), 'missing', len(refs - cell_files))
check(cell_files == refs, 'cell files == referenced')

# --- counts
nraw = sum(len(v) for p in raw.values() for v in p.values()) + len(standing)
by = {pid: sum(len(v) for v in raw[pid].values()) for pid in raw}
print('raw counts', nraw, 'standing', len(standing), by, 'free pack (no idle)', nraw - by.get('idle', 0))

# --- mirror substitution: each view vs horizontally flipped counterpart, any shift
def best_flip_diff(a, b):
    """min over integer x-shifts of RGBA-differing pixels between a and flipped b (same canvas)."""
    fb = b[:, ::-1]
    best = None
    for s in range(-16, 17):
        sh = np.roll(fb, s, axis=1)
        n = int(np.any(a != sh, axis=2).sum())
        best = n if best is None else min(best, n)
    return best
mir = {}
for name, frames in [('standing', {d: {0: standing[d]} for d in DIRS})] + [(p, raw[p]) for p in ['idle', 'walk', 'slash']]:
    for d in ['east', 'south-east', 'north-east']:
        md = MIRROR[d]
        diffs = [best_flip_diff(frames[d][i], frames[md][i]) for i in frames[d] if frames[d][i].shape == frames[md][i].shape]
        mir[f'{name}:{d}/{md}'] = (min(diffs), max(diffs))
    hs = [rgba_hash(frames[d][i]) for d in DIRS for i in frames[d]]
    check(len(set(hs)) == len(hs), f'{name}: duplicate frame hash across views/frames ({len(hs) - len(set(hs))})')
    print(name, 'distinct frame hashes', len(set(hs)), '/', len(hs))
print('mirror min/max differing px after best flip+shift', json.dumps(mir))

# --- ready-pose (slash raw 7) vs standing
print('ready-pose (slash 7) vs standing, both on 112 canvas:')
for d in DIRS:
    off = (L['offsets']['slash'][d]['x'], L['offsets']['slash'][d]['y'])
    r7 = place(raw['slash'][d][7], CELL, off); st = placed_standing[d]
    al = int(((r7[:, :, 3] > 0) != (st[:, :, 3] > 0)).sum())
    both = (r7[:, :, 3] > 0) & (st[:, :, 3] > 0)
    rgb = int((np.any(r7[:, :, :3] != st[:, :, :3], axis=2) & both).sum())
    anyd = int(np.any(r7 != st, axis=2).sum())
    print(f'  {d:10s} alphaDiff={al} rgbDiffBothOpaque={rgb} rgbaDiffAny={anyd}')
print('idle raw 0 vs standing:')
for d in DIRS:
    off = (L['offsets']['idle'][d]['x'], L['offsets']['idle'][d]['y'])
    i0 = place(raw['idle'][d][0], CELL, off); st = placed_standing[d]
    print(f'  {d:10s} alphaDiff={int(((i0[:,:,3]>0)!=(st[:,:,3]>0)).sum())} rgbaDiffAny={int(np.any(i0!=st,axis=2).sum())}')

# --- walk seam per view
print('walk silhouette XOR between consecutive frames (i->i+1), last is 7->0; plus bbox top/bottom deltas')
for d in DIRS:
    fr = [raw['walk'][d][i][:, :, 3] > 0 for i in range(8)]
    x = [int((fr[i] != fr[(i + 1) % 8]).sum()) for i in range(8)]
    def bb(f):
        ys = np.nonzero(f.any(axis=1))[0]; return int(ys.min()), int(ys.max())
    tb = [(bb(fr[(i + 1) % 8])[0] - bb(fr[i])[0], bb(fr[(i + 1) % 8])[1] - bb(fr[i])[1]) for i in range(8)]
    rgba = [int(np.any(raw['walk'][d][i] != raw['walk'][d][(i + 1) % 8], axis=2).sum()) for i in range(8)]
    print(f'  {d:10s} xor={x} seam={x[7]} maxOther={max(x[:7])} rank={sorted(x, reverse=True).index(x[7]) + 1}/8 topBottom={tb} rgbaDiff={rgba}')
    # single connected component check
from collections import deque
def components(mask):
    seen = np.zeros_like(mask); n = 0; H, W = mask.shape
    for y, x in zip(*np.nonzero(mask)):
        if seen[y, x]: continue
        n += 1; q = deque([(y, x)]); seen[y, x] = True
        while q:
            cy, cx = q.popleft()
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    ny, nx = cy + dy, cx + dx
                    if 0 <= ny < H and 0 <= nx < W and mask[ny, nx] and not seen[ny, nx]: seen[ny, nx] = True; q.append((ny, nx))
    return n
wc = [components(raw['walk'][d][i][:, :, 3] > 0) for d in DIRS for i in range(8)]
print('walk 8-connected opaque components per frame: max', max(wc), 'frames with >1:', sum(c > 1 for c in wc))
gray = {p: {d: [int(np.all(raw[p][d][i][:, :, :3] == 128, axis=2)[raw[p][d][i][:, :, 3] > 0].sum()) for i in sorted(raw[p][d])] for d in DIRS} for p in raw}
print('exact RGB128 opaque counts:', json.dumps(gray))

# --- metadata: no fabricated joints/timing
s = json.dumps(proj)
print('project keypoint arrays:', s.count('"keypoints"'), 'anchors' in rig, 'fps' in s.lower(), 'duration' in s.lower())
check(s.count('"keypoints"') == 8, 'only 8 rest keypoint arrays')
check('anchors' not in rig, 'no anchors')
print('evidence flags', ev['qualified'], ev['equippedQualified'], ev['providerTiming'], 'qa', m['items'][0]['qa']['status'], m['items'][0]['qa']['unmeasured'], m['items'][0]['designWarnings'])
print('png modes', modes)
print('FAILURES', len(fail)); [print('  -', f) for f in fail[:40]]
