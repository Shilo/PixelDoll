"""Count exact RGB128 pixels outside the largest opaque component (4- and 8-connectivity). Usage: python -P -E gray_detached.py <starter dir>"""
import sys, os
import numpy as np
from PIL import Image
from scipy import ndimage
R = sys.argv[1]
for d, i in (('south', 0), ('east', 2)):
    a = np.array(Image.open(os.path.join(R, 'raw', 'slash', d, f'{i}.png')).convert('RGBA'))
    op = a[:, :, 3] > 0; gray = op & np.all(a[:, :, :3] == 128, axis=2)
    for name, st in (('4conn', ndimage.generate_binary_structure(2, 1)), ('8conn', ndimage.generate_binary_structure(2, 2))):
        lab, n = ndimage.label(op, st); sizes = ndimage.sum(op, lab, range(1, n + 1)); main = 1 + int(np.argmax(sizes))
        nongray = op & ~gray; glab, gn = ndimage.label(gray, st)
        touching = sum(1 for k in range(1, gn + 1) if (ndimage.binary_dilation(glab == k, st) & nongray).any())
        detached_from_body = int((gray & (lab != main)).sum())
        gray_not_touching_nongray = int(sum(((glab == k).sum() for k in range(1, gn + 1) if not (ndimage.binary_dilation(glab == k, st) & nongray).any())))
        print(f'slash {d}/{i} {name}: gray={int(gray.sum())} opaqueComponents={n} grayOutsideLargest={detached_from_body} grayComponents={gn} grayPxInComponentsNotTouchingOtherColours={gray_not_touching_nongray}')
