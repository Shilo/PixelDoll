PixelDoll eight-direction starter review, 2026-11-02

Experimental body-only candidate, not a professional/universal preset.

Import the separate native-eight-direction-starter.pixeldoll.zip into Studio. Import is free; leave optional pose setup off to inspect without spending. The app shows any pose setup cost before starting.

Before: idle-authored-contact-sheet.png and timed GIF contain REJECTED generated breathing puffs. After: idle-standing-authored-contact-sheet.png shows exact source still idle, not animated breathing.

Attack authored sheet/GIF selects the same native samples [7,1,1,3,4,5,6,7] in every view. Rejected raw samples 0/2 remain in raw/ inside the separate project ZIP; no anatomy was erased.

Review GIFs may repeat to aid inspection. Project attack metadata is nonlooping; walk loops; still idle is one cell with four 150 ms holds. Default timing is author choice, not provider metadata.

Full native raw PNGs and exact per-image hashes are in the separate project ZIP. This review ZIP contains readable sheets, descriptive raster audits, actual UI proof, sanitized receipts/billing and source-bound review notes. It contains no token, environment file or browser profile.

Final software checks: strict0errors0warnings;1,493 unit passes and one existing skip;12 relevant browser passes, including malformed optional idle/free-export controls. Actual generated art UI:24previews,8directions,4moves,168rawimages,exactstandingidle,0APIrequests0pageerrors.

Cost:74.25newgenerations, including24rejected-idle researchunits. Source2.25+walk24+attack24+idle24. No more paidwork planned. Prior15fromlatest500allowance,89.25total,410.75remaining.

See docs/research/2026-11-02-eight-direction-starter-pack.md for conclusions, rejection history and remaining limits.
