One PNG strip per item layer, move and direction: <item>_<layer>/<move>_<direction>_strip<frames>.png.
Frames sit left to right, each one cell of the layer (manifest.json items[].layers[].cell); columns are zero-based source cell indices.
Play rig.animations[].frames in order: use each entry's cell column for ms milliseconds, including repeated indices. Repeat only when loop is true.
The _stripN suffix lets GameMaker split the image on import; it does not encode the playlist, frame durations or origin.
Place every layer at character position minus layers[].pivot; oversize layers have their own cell and pivot.
The base is always worn. Resolve slot hiding, tucked variants (variantOf/under) and z order (layers[].z, slots[].zOverrides) from manifest.json.
A strip a move does not have (rig.animations[].directions) or an item has no frames for is left out. Mirrored rows are already flipped.
These strips and layers/ render approved default colorways. To recolor, start from sourceSheets when present (otherwise sheets),
replace each item's material ramp by the selected variant ramp, and follow linkTo/defaultVariant. All outfit ramps are stored in materials[].variants.
Baked sheets in baked/ apply the outfit's colors and layer visibility; their cell and pivot are export.bakedCell and export.bakedPivot.
Use nearest-neighbor filtering, whole-pixel positions and straight RGBA alpha. This is a PNG + JSON interchange format; engine playback needs integration.
