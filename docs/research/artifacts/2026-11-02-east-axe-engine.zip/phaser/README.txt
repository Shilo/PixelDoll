1. Copy the whole export folder into your game's assets, e.g. assets/experimental-east-axe-review/
2. Game config: pixelArt: true, roundPixels: true (Phaser 4 defaults roundPixels to false).
3. In a scene (Phaser 3.80+ or 4):
     import { loadPaperdoll, Paperdoll } from './assets/experimental-east-axe-review/phaser/PaperdollContainer.js'
     async create() {
       const m = await loadPaperdoll(this, 'assets/experimental-east-axe-review/')   // the folder with manifest.json
       const doll = new Paperdoll(this, 200, 150, m)
       doll.play("default", "east")
     }
Switch outfits with doll.applyPreset(m.presets[1]); recolor with doll.setVariants({ material_id: "stored_variant" }).
Palette swaps use exact source RGBs and stored material ramps in Canvas or WebGL.
Call doll.destroy() when removing a character. Palette textures are cached until Phaser game teardown.
PaperdollContainer.js is an ES module and fetches manifest.json: serve the game over http (a dev server), not file://.
Atlases: phaser/<length>-<item>_<length>-<layer>_<length>-<move>.json (TexturePacker hash), frames named <move>_<direction>_<frame>.
