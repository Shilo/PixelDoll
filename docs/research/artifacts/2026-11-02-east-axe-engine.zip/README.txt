EXPERIMENTAL east axe review: a paperdoll character exported by PixelDoll (pixeldoll/2).

Quick start
  Any engine: one PNG strip per layer, move and direction in generic/ (see generic/README.txt).
  Phaser 3.80+ / 4: copy this folder into your assets and use phaser/PaperdollContainer.js (see phaser/README.txt).

What is inside
  manifest.json   rig (cell 144x144, pivot 72,107), moves, slots, items, colors and outfits
  layers/         one sheet per item layer and move: layers/<slot>/<item>/<layer>/<move>.png
                  rows = directions (east), columns = frames
  baked/          the finished character per outfit: baked/<outfit>/<move>.png
  CREDITS.txt     where each item came from (PixelLab calls), CSV
  project.json    editable character for importing back into PixelDoll
  cells/          original frame and rest images for the editable copy

Outfit colors are exact palette swaps (materials[].ramp and variants, presets[].variants); the runtimes swap them while
the character plays, so a game can change them.

Moves: default (1 frames), axe-attack (8 frames).
A move lists the directions it has in rig.animations[].directions; its other sheet rows are empty.
Pixel art: use nearest-neighbor filtering and whole-pixel positions.
