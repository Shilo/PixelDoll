Animation closeout, 2026-11-02

No new PixelLab calls or generations. These files are evidence, not a qualified universal/equipped preset.

actual-closeout-ui-proof.json: actual retained native frames reviewed through the application with all API traffic blocked.
east-walk-contact-review.json: seven candidate visible sole-contour marks; approximate one-pixel landmark uncertainty. Test speed 22.5 native pixels/second, not 95 world units/second.
The sampled residual is 0.75 px per observed stance; held-frame travel is 2.25 px per 100 ms. This DOES NOT prove continuous planting. The last overlapping foot remains unmarked.

actual-unmarked-hand-review.png and actual-invalid-grip-blocked.png: missing/invalid body targets display the exact bare body and cannot export a floating weapon.
actual-transparent-source-anchor.json: even a valid opaque BODY contact cannot rescue an anchor on transparent SOURCE art. This negative control is not a palm annotation.
retained-axe-guard-replay.json: all eight earlier east-axe layers replay pixel-identically, with zero source clipping, through the new guards.

analog-cadence-before-after.gif is a 2D illustration using real production playback helpers and retained East walk. At half input, old gait advances 1,600 ms during 1,600 ms of travel; corrected gait advances 800 ms. It does not measure WorldStage perspective or absolute stride.

Final local checks:1,508 unit passes, one existing skip; strict 0/0; full 169 browsers before final geometric guard; 12 relevant browsers after final guard. Remote CI source/result recorded in repository report.

See docs/research/2026-11-02-animation-closeout.md for scope, counter-review and remaining art limitations.
